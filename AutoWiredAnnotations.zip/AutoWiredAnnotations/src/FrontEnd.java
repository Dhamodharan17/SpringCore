import org.springframework.beans.factory.annotation.Autowired;

public class FrontEnd {

	private BackEnd backend;

	@Autowired
	public FrontEnd(BackEnd backend) {
		
		this.backend = backend;
	}
	
	
	public void callingServices()
	{
		backend.connectBackend();
	}
}
