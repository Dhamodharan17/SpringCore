package ambiguity;

public class BackEnd {

	
	public void connectBackend()
	{
		
		System.out.println("Connected to database");
	}
}
