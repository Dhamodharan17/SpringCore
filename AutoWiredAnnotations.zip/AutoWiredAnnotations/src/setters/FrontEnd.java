package setters;
import org.springframework.beans.factory.annotation.Autowired;

public class FrontEnd {

	private BackEnd backend;

	@Autowired
	public void setBackend(BackEnd backend) {
		this.backend = backend;
	}



	public FrontEnd(BackEnd backend) {
		
		this.backend = backend;
	}
	
	
	public void callingServices()
	{
		backend.connectBackend();
	}
}
