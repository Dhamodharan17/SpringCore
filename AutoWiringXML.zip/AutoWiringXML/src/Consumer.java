
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Consumer {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		//By Name
		//Human human=context.getBean("human",Human.class);
		//human.pumping();
		
		//By Type
		//Human human=context.getBean("humaneye",Human.class);
		//human.sighting();
		
		//By Constructor
		Human human=context.getBean("hear",Human.class);
		human.Hearing();
				
	;
	}
	
}


