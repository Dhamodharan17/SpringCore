
public class Ear {

	public void Hearing()
	{
		System.out.println("Hearing");
	}
}
