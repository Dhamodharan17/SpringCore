
public class Eye {

	public void Sighting()
	{
		System.out.println("Sighting");
	}
	
	
}
