
public class Heart {

	public void pump()
	{
		System.out.println("Heart Pumping");
		System.out.println("Alive");
	}

}
