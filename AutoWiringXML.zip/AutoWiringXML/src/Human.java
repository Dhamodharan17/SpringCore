
public class Human {

	private Heart heart;
	private Eye eye;
	private Ear hear;
	
	public Human()
	{
		
	}
	public Human(Ear hear) {
		
		this.hear = hear;
	}


	public void setEye(Eye eye) {
		this.eye = eye;
	}


	public void setHeart(Heart heart) {
		this.heart = heart;
	}

	public void sighting()
	{
		eye.Sighting();
	}


	public void pumping()
	{
		heart.pump();
	}
	
	public void Hearing()
	{
		hear.Hearing();
	}
}
