
public class MathCheat implements Cheat {

	@Override
	public void cheat() {
		
		System.out.println("Math cheating started");
		
	}

}
