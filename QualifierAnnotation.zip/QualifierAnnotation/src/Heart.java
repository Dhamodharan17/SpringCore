
public class Heart {
	
	private String nameOfAnimal;
	private int noOfHeart;
	public String getNameOfAnimal() {
		return nameOfAnimal;
	}
	public void setNameOfAnimal(String nameOfAnimal) {
		this.nameOfAnimal = nameOfAnimal;
	}
	public int getNoOfHeart() {
		return noOfHeart;
	}
	public void setNoOfHeart(int noOfHeart) {
		this.noOfHeart = noOfHeart;
	}
	
	public void displayDetails()
	{
		System.out.println("Name of the animal is : "+getNameOfAnimal()+" and No. of hearts "+getNoOfHeart());
	}

}
