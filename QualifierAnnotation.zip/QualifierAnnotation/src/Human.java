import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Human {

	@Autowired
	@Qualifier("humanheart")
	private Heart heart;

	/*.
	 * No need of setters in case of qualifiers
	 * @Autowired
	@Qualifier("humanheart")
	public void setHeart(Heart heart) {
		this.heart = heart;
	}
	
	*/
	
	
	public void getDetails()
	{
		heart.displayDetails();
	}
}
