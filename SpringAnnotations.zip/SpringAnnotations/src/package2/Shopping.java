package package2;
import org.springframework.stereotype.Component;

@Component("doshop")
 class Shopping {

	public void shop()
	{
		System.out.println("Shopping started");
	}

	
	
}
