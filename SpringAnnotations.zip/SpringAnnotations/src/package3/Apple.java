package package3;

public class Apple {

	public void product()
	{
		System.out.println("Finnaly I brought apple");
	}
}
