package package3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Consumer {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(ShoppingConfig.class);
		Shopping college =context.getBean("ShopBean",Shopping.class);
		college.shop();

	}

}
