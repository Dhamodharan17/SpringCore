package package3;

public class Shop {

	private Apple apple;
	
	public void setApple(Apple apple) {
		this.apple = apple;
	}

	public void eproducts()
	{
	apple.product();
	}
}
