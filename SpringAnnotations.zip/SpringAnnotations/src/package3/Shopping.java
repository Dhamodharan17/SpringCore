package package3;


 class Shopping {

	 private Shop shop;
	 
	public Shopping(Shop shop) {
		
		this.shop = shop;
	
	}

	public void shop()
	{
		shop.eproducts();
	
	}

	
	
}
