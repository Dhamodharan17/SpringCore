package package3;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ShoppingConfig {

	@Bean
	public Apple apple()
	{
		return new Apple();
	}
	
	@Bean
	public Shop shop()
	{
		Shop shop=new Shop();
		shop.setApple(apple());
		return shop;
	}
	/*
	@Bean
	public Shopping ShopBean()
	{
		return new Shopping(shop());
	}
	*/
	
	@Bean
	public Shopping ShopBean()
	{
		Shopping shop =new Shopping(shop());
		return shop;
		
	}
}
