package package4;

public class Math implements Teachable {

	public void teach()
	{
		System.out.println("Teach maths");
	}
}
