package package4;

public class Sci implements Teachable {

	public void teach()
	{
		System.out.println("Teach Science");
	}
}
