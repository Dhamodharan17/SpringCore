package package4;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ShoppingConfig {

	@Bean
	public Student student()
	{
		return new Student(teachable());
	}
	
	
	@Bean
	public  Teachable teachable()
	{
		return new Math();
	}
}
