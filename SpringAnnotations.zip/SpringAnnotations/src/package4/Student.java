package package4;

public class Student {

	private Teachable teach;
	
	public Student(Teachable teach) {
		
		this.teach = teach;
	}

	public void teachcall()
	{
		teach.teach();
	}
}
