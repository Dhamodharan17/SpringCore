package package4;

public interface Teachable {
public void teach();
}
