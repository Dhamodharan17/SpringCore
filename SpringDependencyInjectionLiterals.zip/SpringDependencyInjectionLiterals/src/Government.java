import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Government {

	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Schools pmr=context.getBean("pmr",Schools.class);
		pmr.displayDetails();
		Schools mctm=context.getBean("mctm",Schools.class);
		mctm.displayDetails();
		

	}

}
