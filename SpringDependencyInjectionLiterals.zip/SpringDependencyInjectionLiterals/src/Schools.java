
public class Schools {

	private String medium;
	private int fund;
	public Schools(String medium)
	{
		this.medium=medium;
	}
	
		
	public Schools(String medium, int fund) {
	
		this.medium = medium;
		this.fund = fund;
	}
	
	public void displayDetails()
	{
		System.out.println("The medium of the school is : "+medium+" and fund provided is : "+fund);
	}
	
	
	
}


