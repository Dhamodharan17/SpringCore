package setterinjection;

public class Vehicle {

	private String name;
	private int number;
	
	public void setName(String name) {
		
		this.name = name;
		
	}
	public void setNumber(int number) {
		
		this.number = number;
		
	}
	
public void getDetails()
{
	System.out.println("Name of the bike is : "+name+" and its number is : "+number );
}
	
	
}
