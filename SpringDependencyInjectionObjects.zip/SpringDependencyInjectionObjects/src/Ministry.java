
public class Ministry {

		
		public void setVoters(Voters voters) {
		this.voters = voters;
	}


		private Voters voters;
		
		
		public void needVotes()
		{
			voters.Vote();
		}
		

}
