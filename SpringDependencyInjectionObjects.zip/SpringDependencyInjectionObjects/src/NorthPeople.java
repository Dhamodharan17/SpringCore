
public class NorthPeople implements Voters{

	@Override
	public void Vote() {
	
		System.out.println("Vote from north india");
		
	}

}
