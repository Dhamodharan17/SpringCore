
public class SouthPeople implements Voters {

	@Override
	public void Vote() {
	
		System.out.println("Vote from south india");
	
		
	}

	
	
	
}
