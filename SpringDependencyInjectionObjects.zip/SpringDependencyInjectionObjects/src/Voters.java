
public interface Voters {

	
	
	
	public void Vote();
}
