package springioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Consumer {

	public static void main(String[] args) {
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("xml file loaded");
		
		RBI bank=context.getBean("bank",RBI.class);
		bank.deposit();
	}
	
}


