package springioc;

public class Control {

	public static void main(String[] args) {
		
		RBI icicbank=new IcIc();
		icicbank.deposit();
		
		RBI indianbank=new IndianBank();
		indianbank.withdraw();

	}

}
