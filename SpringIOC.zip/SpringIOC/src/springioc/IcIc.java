package springioc;

public class IcIc implements RBI {

	public IcIc()
	{
		System.out.println("ICIC : Constructor called. I.e. Object created");
	}
	
	
	@Override
	public void deposit() {
	
		System.out.println("ICIC : We will provide more interset");
	}

	@Override
	public void withdraw() {
	
		System.out.println("ICIC : Take ur money without hassle");
	}
	
	
	

}
