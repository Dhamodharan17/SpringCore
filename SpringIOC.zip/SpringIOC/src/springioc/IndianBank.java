package springioc;

public class IndianBank implements RBI {

	@Override
	public void deposit() {
	
		System.out.println("Indian Bank : We will provide more interset");
	}

	@Override
	public void withdraw() {
	
		System.out.println("Indian Bank : Take ur money without hassle");
	}
	

}
