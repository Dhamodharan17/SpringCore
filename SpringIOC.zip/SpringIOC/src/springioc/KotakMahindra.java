package springioc;

public class KotakMahindra implements RBI {

	@Override
	public void deposit() {
	
		System.out.println("Kotak : We will provide more interset");
	}

	@Override
	public void withdraw() {
	
		System.out.println("Kotak : Take ur money without hassle");
	}
	
}
