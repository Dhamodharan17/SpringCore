package springioc;

public interface RBI {
	
	public void deposit();
	public void withdraw();

}
