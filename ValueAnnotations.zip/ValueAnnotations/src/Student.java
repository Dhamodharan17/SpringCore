import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;

public class Student {
	
	
/*	Field level declarations no need setters
	@Value("${student.name}")
	private String name;
	@Value("${student.course}")
	private String course;
	@Value("${student.hobby}")
	private String hobby;
	*/
	
	private String name;
	private String course;
	private String hobby;
	 
	@Required
	@Value("${student.name}")
	public void setName(String name) {
		this.name = name;
	}
	
	@Value("${student.course}")
	public void setCourse(String course) {
		this.course = course;
	}
	@Value("${student.hobby}")
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	
	
	
	
	public String getName() {
		return name;
	}
	
	public String getCourse() {
		return course;
	}
	
	public String getHobby() {
		return hobby;
	}
	

	public void studentDetails()
	{
		System.out.println("Name of the student : "+getName()+ " course wanted : "+getCourse()+" hobby is : "+getHobby());
	}
}
